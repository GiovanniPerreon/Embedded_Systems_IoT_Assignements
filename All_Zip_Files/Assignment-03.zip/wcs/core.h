#ifndef __CORE__
#define __CORE__

#define INIT_STATE   1
#define RUNNING_STATE  2

void initCore();
void initState();
void runningState();

#endif
