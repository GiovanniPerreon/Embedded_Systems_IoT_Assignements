#ifndef __GENERATESQ__
#define __GENERATESQ__

void generate(int array[]);

bool isEqual(int a1[], int a2[]);

bool isPresent(int array[], int i);

#endif
